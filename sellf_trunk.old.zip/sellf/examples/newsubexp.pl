subexp as unb.
subexp bs lin.

context as.

empty :- new_subexp cs, (empty [cs]-o top), [as]bang top.

