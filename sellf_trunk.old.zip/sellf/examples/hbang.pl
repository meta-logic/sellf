subexp un unb.
subexp li2 lin.
subexp li lin.

context li2.

a 2.

context li.

a 1.

context un.

empty :- [li]hbang top.

