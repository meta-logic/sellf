open Printf

module TestUnify = 
  Unify.Make(struct
                      let instantiatable = Term.LOG
                      let constant_like = Term.EIG
             end)
    
let position lexbuf =
  let curr = lexbuf.Lexing.lex_curr_p in
  let file = curr.Lexing.pos_fname in
  let line = curr.Lexing.pos_lnum in
  let char = curr.Lexing.pos_cnum - curr.Lexing.pos_bol in
    if file = "" then
      () (* lexbuf information is rarely accurate at the toplevel *)
    else
      print_string "";Format.sprintf ": line %d, character %d" line char

let rec start () = 
  Structs.clear_tables ();
  print_string ":> ";
    let command = read_line() in
      try 
      let lexbuf_top = Lexing.from_string command in 
      let action = Parser.top Lexer_top.token lexbuf_top in 
	match action with
      | "help" -> start ()
      | "verbose-on" -> print_endline "Verbose is set to on."; Structs.verbose := true; start ()
      | "verbose-off" -> print_endline "Verbose is set to off."; Structs.verbose := false; start ()
      | "time-on" -> Structs.time := true; print_endline "Time is set to on."; start ()
      | "time-off" -> Structs.time := false; print_endline "Time is set to off."; start ()
      | file_name -> 
          let file_name = "../examples/ll" in
          begin
          print_endline ("Loading file"^file_name);
          let file_sig = open_in (file_name^".sig") in
          let lexbuf = Lexing.from_channel file_sig in
            begin
            try 
              while true do
                Parser.types Lexer.token lexbuf
              done
            with 
              |  Lexer.Eof -> 
                   let file_prog = open_in (file_name^".pl") in 
                  let lexbuf = Lexing.from_channel file_prog in
                    begin
                      try
                      while true do
                        Parser.clause Lexer.token lexbuf
                      done  
                    with 
                      | Lexer.Eof -> if !Structs.permut then solve_permut file_name else solve_query ()
                      | Parsing.Parse_error ->  Format.printf "Syntax error while parsing .pl file%s.\n%!" (position lexbuf); start ()
                      | Failure str -> Format.printf ("ERROR in .pl file: %s\n%!") (position lexbuf); print_endline str; start ()
                    end
              |  Parsing.Parse_error ->  Format.printf "Syntax error while parsing .sig file%s.\n%!" (position lexbuf); start ()
              |  Failure _ -> Format.printf "Syntax error in .sig file: %s.\n%!" (position lexbuf); start ()
          end
        end
    with
      |  Parsing.Parse_error ->  print_endline "Invalid command. For more information type #help."; start  ()
    |  Sys_error str -> print_string ("Error"^str); print_endline ". Please double check the name of the file."; start ()
and
solve_query () = 
  print_string "?> ";
  let query_string = read_line() in
    let query = Lexing.from_string query_string in
      begin
	try 
        Parser.goal Lexer.token query;
	if !Structs.time then begin
	  let start_time = Sys.time () in
            Interpreter.solve (fun () -> 
			       if (Interpreter.empty_nw ()) then 
              print_string "\nYes.\n"
            else (Structs.last_fail ()))  
            (fun () -> print_string "\nNo.\n");
	    let end_time = Sys.time () in
	  let total = end_time -. start_time in
	    Printf.printf "Execution time: %f seconds.\n" total
        end
	else 
          Interpreter.solve (fun () -> 
			       if (Interpreter.empty_nw ()) then 
				 print_string "\nYes.\n"
			       else (Structs.last_fail ()))  
            (fun () -> print_string "\nNo.\n");
	
	with
          | Parsing.Parse_error -> Format.printf "Syntax error%s.\n%!" (position query); solve_query ()
          | Failure str -> Format.printf "ERROR:%s\n%!" (position query); print_endline str; start()
      end
and 
    solve_permut file_name = 
  let file_prog = open_in (file_name^".pr") in 
  let lexbuf = Lexing.from_channel file_prog in
    begin
      try
	while true do
          Parser.permut Lexer.token lexbuf
	done  
      with 
	| Lexer.Eof -> 
	    let cls_list = Hashtbl.find !Structs.context "un" in
	    let cls1 = Interpreter. apply_ptr (List.nth cls_list 1) in
	    let cls2 = Interpreter. apply_ptr (List.nth cls_list 0) in
	      (* Auxiliary initial functions *)
	    let finitPf tree = "" in
	    let fInit tr = tr in
	    (*   (\* Create an initial context for the root sequent. *\) *)
	    (* let fCtxInit1 = Permutation.create_initial_ctx () in *)
	    (* let fCtxInit2 = Permutation.create_initial_ctx () in  *)
	    (*   (\* Root sequent. *\) *)
	    (* let seq1 = Permutation.SEQ([],  Permutation.LFT (!Structs.subexpLeft, fCtxInit1),   *)
	    (* 		   Permutation.RGHT (!Structs.subexpRight, fCtxInit1)) in *)
	    (*   (\* print_term cls1; print_string "\n\n";  print_term cls2; *\) *)
	    (* let _ = Permutation.build_2_bipole cls1 cls2 seq1 in *)
	      (* Permutation.print_bipole seq cls1; *)
	    let final_constraints = Tosmodels.get_constraints cls1 cls2 in
	        start()
              (* Permutation.print_bipole_list seq cls_list; start() *)
        | Parsing.Parse_error ->  Format.printf "Syntax error while parsing .pr file%s.\n%!" (position lexbuf); start ()
        | Failure str -> Format.printf ("ERROR in .pr file: %s\n%!") (position lexbuf); print_endline str; start ()
    end
      
let _ = 
print_endline "SELLF -- A linear logic framework for systems with locations.";
print_endline "Version 0.5.\n";
while true do
start ()
done
