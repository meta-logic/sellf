open Term
open Structs
open Unify
open Interpreter

(*There are a number of types of constraints. 
- FAIL issued when the set of constraints is unsatisfiable;
- MCTX denotes that a term belongs to an unbounded context;
- ELIN denotes that a term is the only element in a linear context;
- EMP denotes that a context is empty;
- EQT denotes that two terms (formulas) are in fact the 
same occurrence of a formula ()
- EQ denotes that the union of a collection of contexts is 
  equal to the union of the second collection of contexts.
*)
type const = 
  | NONE
  | FAIL
  | MCTX of terms * terms
  | ELIN  of terms * terms
  | EMP of terms
  | EQT of terms * terms
  | EQ of terms list * terms list

(*A sequent has a left and a right side which are basically a 
list of subexponential names and a function from this list
to lists of terms.*)
type sequent = 
  | LFT of string list * (string -> (terms list))
  | RGHT of string list * (string -> (terms list))
  | SEQ of (int list) * sequent * sequent

(*Proof trees have nodes, closed and/or open sequents.
The term in the open sequent is the "instruction"
that is left to be performed. Here we could extend this
so that there are many instructions.*)
type proof_tree = 
  | OLeaf of sequent * terms (*Open leaf.*)
  | CLeaf of sequent * const list list * terms (*Closed leaf.*)
  | Node of proof_tree * proof_tree

let rec print_constraints lcons = 
  match lcons with
    | [] -> ()
    | FAIL :: b -> print_string "Invalid tree!"
    | MCTX (t, tc) :: b ->
	print_term t; 
	print_string " belongs to the context "; 
	print_term tc;
	print_string "\n";
	print_constraints b
    | ELIN (t, lt) :: b ->
	print_term t; 
	print_string " is the only element of the context "; 
	print_term lt;
	print_string "\n";
	print_constraints b
    | EMP (lt) :: b -> 
	print_string ("The following context is  empty ");
	print_term lt;
	print_string "\n";
	print_constraints b
    | EQT (t1, t2) :: b -> 
	print_term t1; 
	print_string " is the same term as ";
	print_term t2; 
	print_constraints b
    | EQ (eq1, eq2) :: b -> 
	print_list_terms eq1; 
	print_string " contains the same elements as the context(s) ";
	print_list_terms eq2; 
	print_string "\n";
	print_constraints b

let rec print_list_constraints lcstr = 
  match lcstr with
    | [] -> ()
    | t :: b -> 
	print_string "\n NEW CONSTRAINT  \n\n";
	print_constraints t;
	print_list_constraints b

let rec sequent_to_string seq = 
  match seq with
  | SEQ (leig, lft, rght) ->  
      let lft_str = sequent_to_string lft in
      let rgth_str = sequent_to_string rght in
	lft_str^" --> "^rgth_str
  | LFT([], f) -> ""
  | LFT(sub::b, f) -> 
      let sub_str = (" ["^sub^"]"^": ") in 
      let lstr = List.map (term_to_string) (f sub) in
      let str_ctx = String.concat ", " lstr in
	sub_str^str_ctx^(sequent_to_string (LFT(b, f)))
  | RGHT([], f) -> ""
  | RGHT(sub::b, f) -> 
      let sub_str = (" ["^sub^"]"^": ") in 
      let lstr = List.map (term_to_string) (f sub) in
      let str_ctx = String.concat ", " lstr in
	sub_str^str_ctx^(sequent_to_string (LFT(b, f)))

(*Function that prints a sequent and its contexts.*)
let rec print_sequent seq = 
  print_string (sequent_to_string seq)
  (* match seq with *)
  (* | SEQ (leig, lft, rght) ->   *)
  (*     print_sequent lft;  *)
  (*     print_string " --> ";  *)
  (*     print_sequent rght; *)
  (* | LFT([], f) -> () *)
  (* | LFT(sub::b, f) ->  *)
  (*     print_string (" ["^sub^"]"^": "); *)
  (*     print_list_terms (f sub);  *)
  (*     print_sequent (LFT(b, f)) *)
  (* | RGHT([], f) -> () *)
  (* | RGHT(sub::b, f) ->  *)
  (*     print_string (" ["^sub^"]"^": "); *)
  (*     print_list_terms (f sub);  *)
  (*     print_sequent (RGHT(b, f)) *)

let get_seq_subs seq = 
  match seq with
    | SEQ (_, LFT(idxl, _), RGHT(idxr, _)) -> (idxl, idxr)


(* Function that prints a list of sequents. *)
let rec print_list_sequents  lseq = 
  match lseq with
   | [] -> ()
  | OLeaf (seq, t) :: b -> 
      print_string "\n Open premise: \n";
      print_sequent seq; 
      print_list_sequents b
  | CLeaf (seq, cnts, t) :: b -> 
      print_string "\n Closed premise: \n";
      print_sequent seq;
      print_string " -- using the term/formula  ";
      print_term t;
      print_list_sequents b
     
(*Function that prints the open and closed leaves of 
a proof tree.*)   
let rec print_tree tree = 
  match tree with 
  | OLeaf (seq, t) -> 
      print_string "Open premise: ";
      print_sequent seq
  | CLeaf (seq, cnts, t) -> 
      print_string "Closed premise: ";
      print_sequent seq;
      print_string " -- using the term/formula  ";
      print_term t
  | Node(tree1, tree2) -> 
      print_tree tree1; 
      print_string "\n";
      print_tree tree2

(*Function that appends two contexts. This is used by the 
tensor rule to join two premises. 
There is an invariant that the unbounded contexts in two 
different branches are the same.*)
let rec app_contexts ctx1 ctx2 = 
  match ctx1, ctx2 with
  | LFT([], f1), _ -> ctx2
  | LFT(str :: b, f1), LFT(subs, f2) when Hashtbl.find subexTpTbl str = UNB ->
      (* let term = Hashtbl.find !ctxUnb str in  *)
      let newsubs =  begin if List.mem str subs then subs 
                              else str :: subs end in
      let fnew str1 = 
	begin
          match str1 with
            | st when str1 = str -> f1 str1
            | st -> f2 st
	end in 
      app_contexts (LFT(b, f1)) (LFT(subs, fnew))
  | LFT(str :: b, f1), LFT(subs, f2) when List.mem str subs -> 
      let fnew str1 = 
      begin
        match str1 with
        | st when str1 = str -> (f2 str) @ (f1 str)
        | st -> f2 st
      end in 
      app_contexts (LFT(b, f1)) (LFT(subs, fnew))
  | LFT(str :: b, f1), LFT(subs, f2) -> 
      let fnew str1 = 
      begin
        match str1 with
        | st when str1 = str -> f1 str
        | st ->  f2 st
      end in 
      app_contexts (LFT(b, f1)) (LFT(str :: subs, fnew))
  | RGHT([], f1), _ -> ctx2
  | RGHT (str :: b, f1), RGHT (subs, f2) when Hashtbl.find subexTpTbl str = UNB ->
      (* let term = Hashtbl.find !ctxUnb str in  *)
      let newsubs =  begin if List.mem str subs then subs 
                              else str :: subs end in
      let fnew str1 = 
	begin
          match str1 with
            | st when str1 = str -> f1 str1
            | st -> f2 st
	end in 
      app_contexts (RGHT (b, f1)) (RGHT (subs, fnew))
  | RGHT(str :: b, f1), RGHT(subs, f2) when List.mem str subs -> 
      let fnew str1 = 
      begin
        match str1 with
        | st when str1 = str ->  (f2 str) @ (f1 str)
        | st ->  f2 st
      end in 
      app_contexts (RGHT(b, f1)) (RGHT(subs, fnew))
  | RGHT(str :: b, f1), RGHT(subs, f2) -> 
      let fnew str1 = 
      begin
        match str1 with
        | st when str1 = str ->  f1 str
        | st -> f2 st
      end in 
      app_contexts (RGHT(b, f1)) (RGHT(str :: subs, fnew))
  | SEQ(leig1, lft1, rght1), SEQ(leig2, lft2, rght2) when leig1 = leig2 -> 
      let newlft = app_contexts lft1 lft2 in 
      let newrght = app_contexts rght1 rght2 in 
      SEQ(leig1, newlft, newrght)
  | _,_ -> failwith "ERROR: Trying to append contexts of different types."

let rec create_initial_ctx () =
  let fInit str = [] in
  let subs = !subexpLeft @ !subexpRight in 
  let rec create_aux subs facc = 
    match subs with
      | [] -> facc
      | h :: b -> 
	  num_context := !num_context + 1;
	  let i = !num_context in 
	  let fnew str = begin
	    match str with 
	      | s when s = h -> [INT(i)]
	      | s -> facc s
	  end in 
	    create_aux b fnew
  in
    create_aux subs fInit
(*
Function that creates a new set of contexts that can be used, for example, 
on the left or the right hand side of a sequent in the meta-level.
*)     
let rec create_ctx subs fCtx faccum = 
    match subs with
      | [] -> faccum
	  (* If the subexponential is unbounded, we do not need *)
	  (* to create a new context since they can be weakened/contracted.  *)
      | str :: b when Hashtbl.find subexTpTbl str = UNB ->
          let fnew str1 = begin
            match str1 with
              | st when st = str -> fCtx st
              | st -> faccum st
          end in 
            create_ctx b fCtx fnew
          (* create_ctx b faccum *)
	    (* If the subexponential is linear we need to create a new  *)
	    (* context so that the constraints can specify how they are.  *)
      | str :: b ->
	  num_context := !num_context + 1; 
	  let term =  INT(!num_context)  in
          let fnew str1 = begin
            match str1 with
              | st when st = str -> [term]
              | st -> faccum st
          end in 
            create_ctx b fCtx fnew
    
let not_term t s = not (t = s) 

let is_INT t =  match t with 
  | INT _ -> true 
  | _ -> false 

let is_PTR t =  match t with 
  | PTR  _ -> true 
  | _ -> false 

let is_Form t =  match t with 
  | INT  _ -> false
  | _ -> true


(* We need to remove all the PTR terms, since these are necessarily  *)
(* logical variables and hence do not participate of inequalities. *)
  let not_PTR t = 
    match t with
      | APP(_, [PTR _]) -> false
      | _ -> true

let build_EMP s = EMP(s) (*  type const *)

(*Function that creates a constraint for a closed leaf.
Here the input t is the positive atomic formula focused on.*)
let rec create_cnst_closed_leaf subs t fCtx = 
  let linSubs = List.filter is_LIN subs in (*  type term list *)
  let linCtxs =  List.flatten (List.map fCtx linSubs) in (*  type term list *)
  let build_term_equ t s = [EQT(t, s)]  in  (*  type const *)
  let rec build_linear_constraints_aux t ltrem ltall acc = (*  const list list *)
    match ltrem with
      | [] -> acc             (* cons list list  *)
      | h :: b -> 
	  (* There are two types of constraints that need to be built. Either the  *)
	  (* context contains exactly one formula, or a formula is equal to another  *)
	  (* formula. *)
	  let elin = begin
	      match h with
		| INT _ -> ELIN(t, h) 
		| PTR _ -> EQT(t, h)
	    end in  (* const *)
	  let lrem = List.filter (not_term h) ltall in   (* term list *)
	  let lemp = List.map build_EMP lrem in  (* const list *)
	  let lres = [elin] @ lemp in                          (* const list *)
	    build_linear_constraints_aux t b ltall (lres :: acc)
  in
  let rec create_cnst_closed_leaf_aux t subs fCtx acc =
    match subs with 
      | [] -> acc
      | s :: b -> 
          begin
            match Hashtbl.find subexTpTbl s with 
		(* If a subexponential is linear (or relevant) then its context can only  *)
		(* have one element. *)
	      | LIN | REL -> 
		  let linSubs' = List.filter (not_term s) linSubs in (* term list *)   
		  let linCtx' = List.flatten (List.map fCtx linSubs') in  (* term list *)   
		  let lLin = build_linear_constraints_aux t (fCtx s) (fCtx s) [] in (* cons list list *)
		  let newAcc = 
		    begin
		      match linCtx' with 
			| [] -> lLin  @ acc 
			| _ ->
	    		    let lEMP' = List.map build_EMP linCtx' in  (* const list *)
			    let cons = List.map (List.append lEMP') lLin in  (* const list list *)
			      cons  @ acc 
		    end in
		    create_cnst_closed_leaf_aux t b fCtx newAcc
		      (* There is an invariant in our program that an unbounded subexponential contains *)
		      (* at most one INT(i). The remaining terms are necessarily complex terms. *)
	      | AFF | UNB ->
		  let sunb = fCtx s in
		  let [set] = List.filter is_INT sunb in
		  let lEMP = List.map build_EMP linCtxs in 
		  let mctx = (MCTX (t, set)) :: lEMP in
		  let lptr =  List.filter is_Form sunb in
		    begin
		      match lptr with
			  (* No need to add the equality constraints if the context for s does  *)
			  (* not contain any formulas explicitly *)
			| [] ->
 			    let newAcc = mctx  :: acc in
			      create_cnst_closed_leaf_aux t b fCtx newAcc
			| _ ->
			    let eqTerms = List.map (build_term_equ t) lptr in
			    let eqCons = List.map (List.append  lEMP) eqTerms in
 			    let newAcc = mctx  :: (eqCons @ acc) in
			      create_cnst_closed_leaf_aux t b fCtx newAcc
		    end
	  end
  in
    create_cnst_closed_leaf_aux t subs fCtx []
      
      
(*Function that creates a context for when a bang is 
introduced.
This functioon is wrong. It should check whether the 
corresponding linear contexts are empty and maintain
the unbounded contexts accordingly. 
*)
  let rec build_context_bang sbang subs fCtx fAcc cAcc = 
    match subs with
      | [] -> (cAcc, fAcc)
	  (* If the the context is in a subexponential greater than  *)
	  (* sbang, then we just leave it as it is. *)
      | str :: b  when greater_than str sbang || str = sbang -> 
	  let fnew str1 = begin
            match str1 with
              | st when st = str -> fCtx st
              | st -> fAcc st
	  end in 
	    build_context_bang sbang b fCtx fnew cAcc
	      (* If the context is in a subexponential that is 
		 not greater than sbang and that context  *)
	      (* is UNB, then we just weaken it. *)
      | str :: b  when  Hashtbl.find subexTpTbl str = UNB -> 
	  let fnew str1 = begin
            match str1 with
              | st when st = str -> []
               | st -> fAcc st
	  end in
	    build_context_bang sbang b fCtx fnew cAcc
	      (* If the context is in a linear subexponential that is not *)
	      (* greater than sbang, then we need to check whether *)
	      (* it contains any formula. If it does, then it is not a tree. *)
	      (* Otherwise, we add constraints to impose that the  *)
	      (* generic contexts are empty. *)
      | str :: b  when  Hashtbl.find subexTpTbl str = LIN ->
	  let lFor = List.filter is_Form (fCtx str) in
	    if lFor = [] then      
	       (* let lEmp = List.map build_EMP (fCtx str) in *)
	       let fnew str1 = begin
		 match str1 with
		   | st when st = str -> []
		   | st -> fAcc st
	       end in
		 build_context_bang sbang b fCtx fnew cAcc
	    else
	       ([FAIL], fAcc)
		
  (*Function that creates a context for when an hbang is 
    introduced.*)
  let rec build_context_hbang sbang fCtx = 
    let fnew str = 
      match str with
	| s1 when s1 = sbang -> []
	| s1 -> fCtx s1
    in
      if Hashtbl.find subexTpTbl sbang = LIN then 
	begin
	  let lFor = List.filter is_Form (fCtx sbang) in
	    if lFor = [] then      
	      ([], fnew)
	      (* let lEmp = List.map build_EMP (fCtx sbang) in *)
	      (* 	(lEmp, fnew) *)
	    else
	      ([FAIL], fnew)
	end 
      else
	([], fnew)
	
  let rec add_sub t1 s fCtx  = 
    let ctxS = fCtx s in
    let fnew str = 
      begin
        match str with
          | st when st = s -> t1 :: ctxS
          | st -> fCtx st
      end in fnew
	       
let rec merge_constraints lc1 lc2 acc =
    match lc1 with
      | [] -> acc
      | h :: b -> 
	  let lc2' = if lc2 = [] then [[]] else lc2 in 
	  let merge1 = List.map (List.append h) lc2' in 
	    merge_constraints b lc2 (merge1 @ acc) 

let build_mem form set = 
  [ MCTX(form, set)]

let rec belong_to_at_most_one lFor lSet acc = 
  match lFor with
    | [] -> acc
    | form :: b -> 
	let cst1 =   List.map (build_mem form) lSet  in (* const list list *)
	let merge = merge_constraints cst1 acc [] in 
	  belong_to_at_most_one b lSet merge


(* The following function generates the constraints that  *)
(* are needed in order to unify two sequents. In particular,  *)
(* one checks for each formula in a linear context that  *)
(* it is also in the same context of the other sequent.  *)	    
let rec unify_sequents seq1 seq2 = 
  match seq1, seq2 with
    | SEQ (_, lft1, rght1), SEQ (_, lft2, rght2) -> 
	let cnst1 = unify_sequents lft1 lft2 in 
	let cnst2 = unify_sequents rght1 rght2 in 
	  cnst1 @ cnst2
    | LFT (lsub1, cL1), LFT (lsub2, cL2) -> 
	begin
	  match lsub1 with
	    | [] -> []
	    | h :: b when List.mem h lsub2 && Hashtbl.find subexTpTbl h = LIN ->
		let ctx1, ctx2 = cL1 h, cL2 h in
		let lFor1 = List.filter is_Form ctx1 in
		let lSet1 = List.filter is_INT ctx1  in
		let lFor2 = List.filter is_Form ctx2 in
		let lSet2 = List.filter is_INT ctx2 in
		let blg1 = belong_to_at_most_one lFor1 lSet2 [] in
		let blg2 = belong_to_at_most_one lFor2 lSet1 blg1 in
		let eq_constr = merge_constraints [[EQ (ctx1, ctx2)]] blg2 [] in
		  merge_constraints eq_constr (unify_sequents (LFT (b, cL1)) (LFT (lsub2, cL2))) []
		    (* The linear contexts of the two sequents have to be the same. *)
		    (* (EQ (cL1 h, cL2 h)) :: (unify_sequents (LFT (b, cL1)) (LFT (lsub2, cL2))) *)
	    | h :: b -> unify_sequents (LFT (b, cL1)) (LFT (lsub2, cL2))
	end
    | RGHT (lsub1, cR1), RGHT (lsub2, cR2) -> 
	begin
	  match lsub1 with
	    | [] -> []
	    | h :: b when List.mem h lsub2 && Hashtbl.find subexTpTbl h = LIN ->
		let ctx1, ctx2 = cR1 h, cR2 h in
		let lFor1 = List.filter is_Form ctx1 in
		let lSet1 = List.filter is_INT ctx1  in
		let lFor2 = List.filter is_Form ctx2 in
		let lSet2 = List.filter is_INT ctx2 in
		let blg1 = belong_to_at_most_one lFor1 lSet2 [] in
		let blg2 = belong_to_at_most_one lFor2 lSet1 blg1 in
		let eq_constr = merge_constraints [[EQ (ctx1, ctx2)]] blg2 [] in
		  merge_constraints eq_constr (unify_sequents (RGHT (b, cR1)) (RGHT (lsub2, cR2))) []
		    (* The linear contexts of the two sequents have to be the same. *)
		    (* (EQ (cL1 h, cL2 h)) :: (unify_sequents (LFT (b, cL1)) (LFT (lsub2, cL2))) *)
	    | h :: b -> unify_sequents (RGHT (b, cR1)) (RGHT (lsub2, cR2))
	end 
	  
(*Main function that computes the bipole trunk 
  of a clause. It returns the root sequent, the whole
  tree, as well as the set of constraints on the contexts.*)
let rec bipole_trunk seq cls  = 
  let f_init str = [] in                            
    (*Function that computes the tree of a negative phase.
      Here we assume a fragment of SELLF, namely that 
      in the left-hand-side there can only be atomic formulas.*)
  let rec neg_trunk_aux (SEQ(leig, cL,cR)) cls = 
    begin
      match cls with
	| FORALL (s, _, f) ->  
            varid := !varid + 1; 
            let eig = !varid in
            let new_var = VAR ({str = s; id = eig; tag = Term.EIG; ts = 0; lts = 0}) in
            let newf = Norm.hnorm (APP (ABS (s, 1, f), [new_var])) in
            let neg_trunk = neg_trunk_aux (SEQ((eig :: leig), cL,cR)) newf in 
              neg_trunk
	| WITH (t1, t2) ->       
            let neg_trunk1 = neg_trunk_aux (SEQ(leig, cL, cR)) t1 in 
            let neg_trunk2 = neg_trunk_aux (SEQ(leig, cL, cR)) t2 in
              Node(neg_trunk1, neg_trunk2)
	| LOLLI (st, t1,t2) ->        
	    (*We are assuming that the left hand side of a lolli is either an atomic formula 
	      or another lolli.*)
	    begin
              match st, cL, cR with 
		| CONS (s), LFT (idxl, f_left), RGHT (idxr, f_right) when  List.mem s idxl -> 
            let contextsL = LFT(idxl, add_sub t2 s f_left) in
            let neg_trunk = neg_trunk_aux (SEQ(leig, contextsL, cR)) t1 in 
              neg_trunk
		| CONS (s), LFT (idxl, f_left), RGHT (idxr, f_right) when  List.mem s idxr -> 
		    (* print_string ("\n Adding: to "^s); print_term t2;  *)
		    let contextsR = RGHT(idxr, add_sub t2 s f_right) in
		    let neg_trunk = neg_trunk_aux (SEQ(leig, cL, contextsR)) t1 in 
		      neg_trunk
	    end
	      (*Top does not create constraints.*)
	| TOP -> CLeaf (SEQ(leig, cL,cR), [], TOP) 
	    (*For all other positive formulas, there is an open leaf in the 
	      negative phase.*)
	| _ -> OLeaf (SEQ(leig, cL, cR), cls)
    end in 
    (*Function that computes the positive trunk introducing a formula.*)
  let rec pos_trunk_aux (SEQ(leig, LFT (idxl, lctx), (RGHT (idxr, rctx)))) cls = 
    match cls with
	(*When a predicate is focused on the right, then one creates a 
	  constraint only when it is positive. Otherwise, we assume that 
	  it is negative, which means that it is an intruction.*)
      | PRED(str, t) -> 
	  let lft_ctx = create_ctx idxl lctx f_init in
	  let rght_ctx = create_ctx idxr rctx f_init in
	  let seq = SEQ(leig, LFT(idxl, lft_ctx), RGHT(idxr, rght_ctx)) in
	    if List.mem str !posAtoms then 
	      begin
		begin
		  match str with 
		    | _ -> 
			let lCnsts = create_cnst_closed_leaf idxr t rght_ctx  in
			  (seq, CLeaf (seq, lCnsts, t), lCnsts)
		end
	      end 
	    else 
	      (*Have to check for atom polarity to see whether this is an open or closed leaf. Also the contexts will change..*)
              (seq, OLeaf (seq, t), [])
      | ONE | PRINT (_) ->              
	  let (lcnstl, lft_ctx) = build_context_bang "unb" idxl lctx f_init [] in
	  let (lcnstr, rght_ctx) = build_context_bang "unb" idxr rctx f_init [] in
	  let seq = SEQ(leig, LFT(idxl, lft_ctx), RGHT(idxr, rght_ctx)) in
            (seq, CLeaf (seq, [], ONE), [lcnstl @ lcnstr] )
	      (*Tensor collects the constraints generated by its branches.*)
      | TENSOR(t1, t2) -> 
	  let fctxlN1 = create_ctx idxl lctx f_init in 
	  let fctxrN1 = create_ctx idxr rctx f_init in 
	  let fctxlN2 = create_ctx idxl lctx f_init in 
	  let fctxrN2 = create_ctx idxr rctx f_init in 
	  let (seq1, tree1, cst1) = pos_trunk_aux (SEQ(leig, LFT (idxl, fctxlN1), (RGHT (idxr, fctxrN1)))) t1 in 
	  let (seq2, tree2, cst2) = pos_trunk_aux (SEQ(leig, LFT (idxl, fctxlN2), (RGHT (idxr, fctxrN2)))) t2 in 
	  let seq_res = app_contexts seq1 seq2 in 
	  let eq_cnst = unify_sequents seq_res (SEQ(leig, LFT (idxl, lctx), (RGHT (idxr, rctx)))) in 
	  let merge_cts = merge_constraints cst1 cst2 [] in
	    (* let merge_with_eq = List.map (List.append eq_cnst) merge_cts in *)
	  let merge_with_eq = merge_constraints eq_cnst merge_cts [] in
            (seq_res, Node(tree1, tree2), merge_with_eq)
      | BRACKET(t) -> pos_trunk_aux (SEQ(leig, LFT (idxl, lctx), (RGHT (idxr, rctx)))) t
      | BANG(st, t) -> 
	  begin
	    match Term.observe st with 
	      | CONS(sub) ->    
		  let (lcnstl, lft_ctx) = build_context_bang sub idxl lctx f_init [] in
		  let (lcnstr, rght_ctx) = build_context_bang sub idxr rctx f_init [] in
		  let seq = SEQ(leig, LFT(idxl, lft_ctx), RGHT(idxr, rght_ctx)) in
		  let neg_trunk = neg_trunk_aux seq t in 
		    (seq, neg_trunk, [lcnstl @ lcnstr])
	  end
      | HBANG(st, t) -> 
	  begin
	    match Term.observe st with 
	      | CONS(sub) ->    
		  let (lcnstl, lft_ctx) = build_context_hbang sub lctx in
		  let (lcnstr, rght_ctx) = build_context_hbang sub rctx  in
		  let seq = SEQ(leig, LFT(idxl, lft_ctx), RGHT(idxr, rght_ctx)) in
		  let neg_trunk = neg_trunk_aux seq t in 
		    (seq, neg_trunk, [lcnstl @ lcnstr])
	  end
	    (*Cases when a negative formula is encountered in a positive phase.*)
      | TOP ->  let idxl = !subexpLeft in 
        let idxr = !subexpRight in
        let contextsL = LFT(idxl, create_ctx idxl lctx f_init ) in
        let contextsR = RGHT(idxr, create_ctx idxr rctx f_init ) in
        let neg_trunk = neg_trunk_aux (SEQ(leig, contextsL, contextsR)) cls in 
          (SEQ(leig, contextsL, contextsR), neg_trunk, [[]])
      | FORALL (_, _, t) ->  
          let idxl = !subexpLeft in 
          let idxr = !subexpRight in
          let contextsL = LFT(idxl, create_ctx idxl lctx f_init ) in
          let contextsR = RGHT(idxr, create_ctx idxr rctx f_init ) in
          let neg_trunk = neg_trunk_aux (SEQ(leig, contextsL, contextsR)) cls in 
            (SEQ(leig, contextsL, contextsR), neg_trunk, [[]])
      | WITH(t1, t2) ->       
          let idxl = !subexpLeft in 
          let idxr = !subexpRight in
          let contextsL = LFT(idxl, create_ctx idxl lctx f_init ) in
          let contextsR = RGHT(idxr, create_ctx idxr rctx f_init ) in
          let neg_trunk = neg_trunk_aux (SEQ(leig, contextsL, contextsR)) cls in 
            (SEQ(leig, contextsL, contextsR), neg_trunk, [[]])
      | LOLLI(s, t1,t2) ->        
          let idxl = !subexpLeft in 
          let idxr = !subexpRight in
          let contextsL = LFT(idxl, create_ctx idxl lctx f_init ) in
          let contextsR = RGHT(idxr, create_ctx idxr rctx f_init ) in
          let neg_trunk = neg_trunk_aux (SEQ(leig, contextsL, contextsR)) cls in 
            (SEQ(leig, contextsL, contextsR), neg_trunk, [[]])
  in 
  let (root_sequent, tree, lcnsts) = pos_trunk_aux seq cls in
    (tree, lcnsts)
      (* let (root_sequent, tree, mem_cnsts) = pos_trunk_aux seq cls in *)
      (* let eq_cnstrs = unify_sequents root_sequent seq in *)
      (* Removing all the trees that have fail. *)
      (* let not_member str l = not (List.mem str l) in *)
      (* let mem_cnsts_no_fail = List.filter (not_member FAIL) mem_cnsts in  *)
      (* (tree, eq_cnstrs, mem_cnsts) *)

let print_bipole seq cls_lolli = 
  match cls_lolli with
      (*We are assuming that the head of a clause is an instruction that is to be matched on 
	the right-hand-side of SELLF. Therefore we do not consider it when constructing a bipole.*)
    | Term.LOLLI(_, _,cls) -> 
        let ( tree, mem_cnsts) = bipole_trunk seq cls in
	  (* let (idxl, idxr) = get_seq_subs seq in  *)
          print_string "\n-------------------------------------------- \n"; 
          print_string "\nRoot Sequent: \n"; 
          print_sequent seq; 
          print_string "\n\nLeaves \n";
          print_tree tree; 
          (* print_string "\n\nwhere \n"; *)
	  (* print_constraints eq_cst;  *)
          print_list_constraints mem_cnsts
    | _ -> ()
	
let rec print_bipole_list seq lcls = 
  begin
    match lcls with 
      | [] -> ()
      | cls1 :: b1 -> print_bipole seq cls1; print_bipole_list seq b1
  end
 

let rec get_leaves tree =
  match tree with 
    | OLeaf _ -> ([tree], [])
    | CLeaf _ -> ([], [tree])
    | Node (tr1, tr2) -> 
	let (lOpen1, lClosed1) = get_leaves tr1 in
	let (lOpen2, lClosed2) = get_leaves tr2 in
	  (lOpen1 @ lOpen2, lClosed1 @ lClosed2) 
	    
let leaf_to_seq leaf = 
  match leaf with
    | OLeaf (seq, t) -> seq
    | CLeaf (seq, cnst, t) -> seq
	
let eq_open_leaves (OLeaf (SEQ(lL1, LFT(lsubl1, cL1), RGHT(lsubr1, cR1)), term1)) 
    (OLeaf (SEQ(lL2, LFT(lsubl2, cL2), RGHT(lsubr2, cR2)), term2)) = 
  if lL1 = lL2 && lsubl1 = lsubl2 && lsubr1 = lsubr2 && term1 = term2 
    && List.map cL1 lsubl1 = List.map cL2 lsubl2 && List.map cR1 lsubr1 = List.map cR2 lsubr2
  then true  else false

let neq_open_leaves open1 open2 = not (eq_open_leaves open1 open2) 

(* Enumerate all possible ways to extend a bipole with another bipole, but by opening
   a single branch at a time.
 *)
let rec build_2_bipole_tree1 cls_lolli1 cls_lolli2 seq = 
  let bipole_trunk_inv cls seq = bipole_trunk seq cls in 
  let rec merge_constraints_list lcnst acc = 
    match lcnst with
      | [] -> acc
      | cnst :: b -> 
	  let constraints =  merge_constraints cnst acc [] in 
	    merge_constraints_list b (constraints @ acc) in
  let add_lOpen lopen (cnstr, lOpen_old, lClosed) = 
    (cnstr, lopen @ lOpen_old, lClosed) in
  let rec build_2_aux lClosed1 mem_cnsts1 cls2 seq lOpen1Prev lOpen1Rem acc =
    match lOpen1Rem with
      | [] -> acc
      | lopen1 :: b ->
  	  let seq_leaf = leaf_to_seq lopen1 in
  	  let (tree_extended, mem_cnsts2) =  bipole_trunk seq_leaf cls2 in
  	  let cnst_merge = merge_constraints mem_cnsts1 mem_cnsts2 [] in
  	  let (lOpen2, lClosed2) = get_leaves tree_extended in
  	  let bleaves = lOpen1Prev @ b in
  	  let lOpenLeaves = bleaves @ lOpen2 in
  	  let lClosedLeaves = lClosed1 @ lClosed2 in
  	  let lOpen1PrevNew = lOpen1Prev @ [lopen1] in
  	  let accNew = (cnst_merge, lOpenLeaves, lClosedLeaves) :: acc in
  	    (* print_list_sequents (lOpenLeaves @ lClosedLeaves); *)
  	    build_2_aux lClosed1 mem_cnsts1 cls2 seq lOpen1PrevNew b accNew
  in
    match cls_lolli1, cls_lolli2 with
	(*We are assuming that the head of a clause is an instruction that is to be matched on 
	  the right-hand-side of SELLF. Therefore we do not consider it when constructing a bipole.
	  We will need to change this soon.*)
      | Term.LOLLI(_, _,cls1), Term.LOLLI(_, _,cls2) -> 
	  let (tree,  mem_cnsts1) = bipole_trunk seq cls1 in
	  let (lOpen1, lClosed1) = get_leaves tree in 
	    build_2_aux lClosed1 mem_cnsts1 cls2 seq [] lOpen1 []

(* Enumerate all possible ways to extend a bipole with another bipole, but by opening
   as many branches at the same time. This is necessary, for instance, when checking 
   whether a tensor permutes over a with.
 *)
let rec build_2_bipole_tree2 cls_lolli1 cls_lolli2 seq = 
  let bipole_trunk_inv cls seq = bipole_trunk seq cls in 
  let rec merge_constraints_list lcnst acc = 
    match lcnst with
      | [] -> acc
      | cnst :: b -> 
	  let constraints =  merge_constraints cnst acc [] in 
	    merge_constraints_list b (constraints @ acc) in
  let add_lOpen lopen (cnstr, lOpen_old, lClosed) = 
    (cnstr, lopen @ lOpen_old, lClosed) in
  let rec build_2_aux lClosed1 mem_cnsts1 cls2 seq lOpen1Prev lOpen1Rem acc = 
    match lOpen1Rem with
      | [] -> acc
      | lopen1 :: b -> 
	  let seq_leaf = leaf_to_seq lopen1 in
	    (* When a with is applied two open leaves are the same and have the  *)
	    (* the same formula to be introduced. So both open leaves have to be introduced. *)
	  let (tree_extended, mem_cnsts2) =  bipole_trunk seq_leaf cls2 in
	  let cnst_merge = merge_constraints mem_cnsts1 mem_cnsts2 [] in
	  let (lOpen2, lClosed2) = get_leaves tree_extended in
	  let bleaves = lOpen1Prev @ b in
	  let lOpenLeaves = bleaves @ lOpen2 in
	  let lClosedLeaves = lClosed1 @ lClosed2 in
	  let lOpen1PrevNew = lOpen1Prev @ [lopen1] in
	  let accNew = (cnst_merge, lOpenLeaves, lClosedLeaves) :: acc in
	  let accRec' = build_2_aux lClosedLeaves cnst_merge cls2 seq [] b [] in
	  let accRec = List.map (add_lOpen lOpen2) accRec' in 
	  let accUpd = accNew @ accRec in 
	    (* print_list_sequents (lOpenLeaves @ lClosedLeaves); *)
	    build_2_aux lClosed1 mem_cnsts1 cls2 seq lOpen1PrevNew b accUpd
  in
    match cls_lolli1, cls_lolli2 with
	(*We are assuming that the head of a clause is an instruction that is to be matched on 
	  the right-hand-side of SELLF. Therefore we do not consider it when constructing a bipole.
	  We will need to change this soon.*)
      | Term.LOLLI(_, _,cls1), Term.LOLLI(_, _,cls2) -> 
	  let (tree,  mem_cnsts1) = bipole_trunk seq cls1 in
	  let (lOpen1, lClosed1) = get_leaves tree in 
	  build_2_aux lClosed1 mem_cnsts1 cls2 seq [] lOpen1 []
