open Term
open Structs
open Unify
open Interpreter
open Printf
open Unix
open Permutation
  
let not_INT t = 
  match t with
    | INT _ -> false
    | _ -> true
	
let rec different_terms ceq h1 h2 = 
  match ceq with
    | [] -> true
    | EQT (t1,t2) :: b when t1 = h1 && t2 = h2 -> false
    | EQT (t2,t1) :: b when t1 = h1 && t2 = h2 -> false
    | _ :: b -> different_terms b h1 h2
	
(* Function that builds part of the equality and  *)
(* not_equ constraints. The only constraints *)
(* missing are those that involve logical variables  *)
(* of two different formulas. *)
let rec build_simple_equalities lterms ceq = 
  let single_constraint t1 t2 = 
    "not_equ("^(term_to_string t1)^","^(term_to_string t2)^")." in
  let not_eq t1 t2 = not (t1 = t2) in 
  let rec build_subformula_aux lterms_iter lterms_all acc = 
    match lterms_iter with
      | [] -> acc
      | h :: b -> 
	  let notH = List.filter (not_eq h) lterms_all in
	  let lNew = List.filter (different_terms ceq h) notH in
	    (* let lnEq = List.map (single_constraint h) lNew in  *)
	  let tr = "form("^(term_to_string h)^")." in
	  let eq = "equ("^(term_to_string h)^","^(term_to_string h)^")." in
	    (* build_subformula_aux b lterms_all ((eq :: tr :: lnEq) @ acc) *)
	    build_subformula_aux b lterms_all (([eq ; tr]) @ acc)
  in
    build_subformula_aux lterms lterms []  
      
let build_int_eq arg1 arg2 =  ("in("^arg1^", "^arg2^")")
  
(* Given a list of terms of the form INT(i), the  *)
(* following function creates a number of intermediate *)
(* set names and connects them by using facts of the *)
(* form "union(X,Y,Z)". *)
let rec build_unions lterms acc =
  let build_mem_aux term = 
    num_context := !num_context + 1; 
    let new_set = (string_of_int !num_context) in
    let mem = "in("^(term_to_string term)^",  "^new_set^")." in
    let unique = ":- in(X, "^new_set^"),"^" in(Y, "^new_set^"), not equ(X, Y), form(X), form(Y)." in
      (INT(!num_context), [mem; unique]) in
    match lterms with
	(* The union of an empty set is the empty set. *)
      | [] -> 
	  num_context := !num_context + 1;
	  let empty = ":- in(X, "^(string_of_int !num_context)^"), form(X)." in
	    (!num_context, [empty])
	      (*  When there is only one element left, then it means  *)
	      (* that no more unions are needed, except if this element is 
		 not a context. In the latter case, we create a new context.*)
      | [t] -> 
	  begin
	    match t with
	      | INT i -> (i, acc)
	      | _ ->	
		let (newCtx, lstr) = build_mem_aux t in
		  (!num_context, lstr @ acc)	  
	  end
      | h :: h2 :: b -> 
	  begin
	    match h, h2 with
	      | INT _, INT _ -> 
		  num_context := !num_context + 1;
		  let new_set = INT(!num_context) in
		  let new_union = "union"^"("^(term_to_string h)^", "^(term_to_string h2)^", "^(term_to_string new_set)^")." in
		    (* We need to include the created set at the beginning of the list so that we  *)
		    (* can build correctly the chain of union. *)
		    build_unions (new_set :: b) (new_union :: acc)
	      | _ , INT _ -> 
		  let (newCtx, lstr) = build_mem_aux h in
		    num_context := !num_context + 1;
		    let new_set = INT(!num_context) in
		    let new_union = "union"^"("^(term_to_string newCtx)^", "^(term_to_string h2)^", "^(term_to_string new_set)^")." in
		      build_unions (new_set :: b) (new_union :: (lstr @ acc))
			(* The following case is symmetric to the previous one.  *)
	      | INT  _ ,  _ -> 
		  let (newCtx, lstr) = build_mem_aux h2 in
		    num_context := !num_context + 1;
		    let new_set = INT(!num_context) in
		    let new_union = "union"^"("^(term_to_string newCtx)^", "^(term_to_string h)^", "^(term_to_string new_set)^")." in
		      build_unions (new_set :: b) (new_union :: (lstr @ acc))
	      | _, _ -> 
		  let (newCtx1, lstr1) = build_mem_aux h in
		  let (newCtx2, lstr2) = build_mem_aux h in
		    num_context := !num_context + 1;
		    let new_set = INT(!num_context) in
		    let new_union = "union"^"("^(term_to_string newCtx1)^", "^(term_to_string newCtx2)^", "^(term_to_string new_set)^")." in
		      build_unions (new_set :: b) (new_union :: (lstr1  @ lstr2 @ acc))		  
	  end 
	    
let rec build_mem_eq_constraints lcnst acc =
  match lcnst with
    | [] -> acc
    | MCTX(ter, set) :: b ->
	let str = "in("^(term_to_string ter)^", "^(term_to_string set)^")." in
	  build_mem_eq_constraints b (str :: acc)
    | ELIN (ter, set) :: b ->
	let str = "in("^(term_to_string ter)^", "^(term_to_string set)^")." in
	let unique = ":- in(X, "^(term_to_string set)^"),"^" in(Y, "^(term_to_string set)^"), not equ(X, Y), form(X), form(Y)." in
	  build_mem_eq_constraints b (str :: unique :: acc)
    | EMP (set) :: b -> 
	let no_ele = ":- in(X, "^(term_to_string set)^"), form(X)." in
	  build_mem_eq_constraints b (no_ele :: acc)
    | EQT(t1, t2) :: b -> 
	let eq_term = "eq("^(term_to_string t1)^", "^(term_to_string t2)^")." in
	  build_mem_eq_constraints b (eq_term :: acc)
    | EQ(lt1, lt2) :: b -> 
	let (i1, union1) = build_unions lt1 [] in
	let set1 = string_of_int i1 in 
	let (i2, union2) = build_unions lt2 [] in
	let set2 = string_of_int  i2 in 
	let eq_set1 = "in(X, "^set1^") :- in(X, "^set2^"), form(X)." in
	let eq_set2 = "in(X, "^set2^") :- in(X, "^set1^"), form(X)." in
	  build_mem_eq_constraints b (eq_set1 :: eq_set2 :: (union1 @ union2 @ acc))
	    
(* Function that collects all the terms that  *)
(* are involved in a list of contraints. *)
let rec collect_terms_constraints lcnst acc = 
  match lcnst with
    | [] -> acc
    | (MCTX (t1, t2)) :: b -> 
	let lterms = List.filter not_INT [t1;t2] in
	  collect_terms_constraints b (lterms @ acc)
    | (ELIN (t1, t2)) :: b -> 
	let lterms = List.filter not_INT [t1;t2] in
	  collect_terms_constraints b (lterms @ acc)
    | EMP(t1) :: b ->  
	let lterms = List.filter not_INT [t1] in
	  collect_terms_constraints b (lterms @ acc)
    | EQT (t1, t2) :: b -> 
	let lterms = List.filter not_INT [t1;t2] in
	  collect_terms_constraints b (lterms @ acc)
    | EQ(lt1, lt2) :: b  ->
	let lterms = List.filter not_INT (lt1 @ lt2) in
	  collect_terms_constraints b (lterms @ acc) 
	    
(* Function that collects all the terms that  *)
(* are involved in a list of contraints. *)
let rec collect_terms_sequents lseq acc = 
  match lseq with
    | [] -> acc
    | (OLeaf (SEQ(lL, LFT(lsubl, cL), RGHT(lsubr, cR)), term)) :: b -> 
	let lterms_ctx = List.flatten ((List.map cL lsubl) @ (List.map cR lsubr)) in
	let lterms = List.filter not_INT (lterms_ctx) in
	  collect_terms_sequents b (lterms @ acc) 
   | CLeaf (SEQ(lL, LFT(lsubl, cL), RGHT(lsubr, cR)), lcnsts, term) :: b -> 
       let lterms_ctx = List.flatten ((List.map cL lsubl) @ (List.map cR lsubr)) in
       let lterms1 = List.filter not_INT (lterms_ctx) in
	 collect_terms_sequents b (lterms1  @ acc)
	   
let termNumber = ref(0)
  
let rec create_rewrite_function lterms facc1 acc2 = 
  match lterms with
    | [] -> (facc1, acc2)
    | h :: b -> 
	termNumber := !termNumber + 1; 
	let num = string_of_int !termNumber in
	let rewrite_term = 	PTR {contents = T (CONS("term"^num))} in
	let new_acc tr =
	  begin
	    match tr with
	      | h' when h' = h -> rewrite_term
	      | _ -> facc1 tr
	  end in
	let comment = "% "^(term_to_string rewrite_term)^" <--> "^(term_to_string h) in
	  create_rewrite_function b new_acc (comment :: acc2)
	    
let rec apply_rewrite lcnst ftrans acc = 
  match lcnst with
    | [] -> acc
    | (MCTX (t1, t2)) :: b -> 
	apply_rewrite b ftrans ((MCTX (ftrans t1, ftrans t2)) :: acc)
    | (ELIN (t1, t2)) :: b -> 
	apply_rewrite b ftrans ((ELIN (ftrans t1, ftrans t2)) :: acc)
    | EMP(t1) :: b ->  
	apply_rewrite b ftrans ((EMP (ftrans t1)) :: acc)
    | EQT (t1, t2) :: b -> 
	apply_rewrite b ftrans ((EQT (ftrans t1, ftrans t2)) :: acc)
    | EQ(lt1, lt2) :: b  ->
	let lt1nu = List.map ftrans lt1 in
	let lt2nu = List.map ftrans lt2 in
	  apply_rewrite b ftrans (EQ(lt1nu, lt2nu)  :: acc) 
	    
let openLeafCounter = ref (0) 

    
let rec create_open_leaf_renaming_function lOseqs facc lcomments = 
  match lOseqs with
    | [] -> (facc, lcomments)
    | h :: b ->   
	openLeafCounter := !openLeafCounter + 1;
	let stri = (string_of_int !openLeafCounter) in
	let faccN leaf = 
	  begin
	    match leaf with
	      | lf when  eq_open_leaves lf h -> 
		  ("leaf"^stri)
	      | lf -> facc lf
	  end in
	let seq_str = sequent_to_string (leaf_to_seq h) in
	  create_open_leaf_renaming_function b faccN (("% leaf"^stri^"  <--->  "^seq_str) :: lcomments)
	    
(* let build_seq_numbering lOpen frw der =  *)
(*   let rec build_seq_aux der str  = "oseq("^str^", "^der^")." in *)
(*   let lOpenrw = (List.map frw lOpen) in *)
(*     List.map (build_seq_aux der) lOpenrw  *)
      
let rec remove_repetitions lst acc = 
  match lst with
    | [] -> acc
    | h :: b when List.mem h acc -> remove_repetitions b acc
    | h :: b -> remove_repetitions b (h :: acc)
	
let build_ctx_numbering fseq fterms der (OLeaf (SEQ(lL, LFT(lsubl, cL), RGHT(lsubr, cR)), term)) = 
  let seq = fseq (OLeaf (SEQ(lL, LFT(lsubl, cL), RGHT(lsubr, cR)), term)) in
  let subs = remove_repetitions (lsubl @ lsubr) [] in 
  let rec build_ctx_aux subs seq fterms cL cR der acc = 
    match subs with
      | [] -> acc
      | sub :: b -> 
	  let ctxs = List.map fterms ((cL sub) @ (cR sub)) in 
	  let (num_ctx, mem_constraints) = build_unions ctxs [] in 
	  let typesub = subexp_type_to_string (Hashtbl.find subexTpTbl sub) in 
	  let ctx_string = "ctx("^(string_of_int num_ctx)^", "^sub^", "^typesub^", "^seq^", "^der^")." in
	    build_ctx_aux b seq fterms cL cR der (ctx_string :: ( mem_constraints @ acc))
  in 
  let ctx_clauses = build_ctx_aux subs seq fterms cL cR der [] in
    ctx_clauses 
      
let build_sexp_constraints () =
  let rec build_geq_aux sub1 sub2 acc =
    if sub2 = "un" || sub1 = "un" then acc
    else 
      let geq_str = "geq("^sub2^", "^sub1^")." in
      let geq_str1 = "geq("^sub1^", "^sub1^")." in
      let geq_str2 = "geq("^sub2^", "^sub2^")." in
	geq_str :: geq_str1 :: geq_str2 :: acc
  in 
  let lgeq = Hashtbl.fold build_geq_aux subexOrdTbl [] in 
    remove_repetitions lgeq []
      
let bind_root_constraints fCtx1 fCtx2 =   
  let subs = !subexpLeft @ !subexpRight in 
  let bind_root_aux fCtx1 fCtx2 sub = 
    match fCtx1 sub, fCtx2 sub with
      | [t1], [t2] -> 
	  let ctx1, ctx2 = term_to_string t1, term_to_string t2 in 
	  let str1 = ":- in(F, " ^ ctx2^"), not in(F, " ^ ctx1 ^ "), form(F).\n" in
	  let str2 = "in(F, " ^ ctx2 ^ "):-  in(F, " ^ ctx1^"), form(F)." in 
	    str1 ^ str2
  in
    List.map (bind_root_aux fCtx1 fCtx2) subs

(*  Theory specifying the set union of two sets. *)
let union_clauses_set =
  "in(X, S) :- in(X, S1), union(S1, S2, S), form(X). \n
in(X, S) :- in(X, S2), union(S1, S2, S), form(X). \n
1 {in(X, S1), in(X, S2)} 1  :- in(X, S),  union(S1, S2, S), form(X). \n"
    
let subsume_clauses der1 der2 =
  "\n1 {provIf(Lf2, Lf1), not_provIf(Lf2, Lf1)} 1 :-  ctx(W1, W2, W3, Lf2, "^der2^"),  ctx(W4, W5, W6, Lf1, "^der1^").\n"
    
let seq_equiv_clauses der1 der2 = 
  "%1 {provIf(Lf2, Lf1), not_provIf(Lf2, Lf1)} 1 :-  ctx(W1, W2, W3, Lf2, tree2),  ctx(W4, W5, W6, Lf1, tree1).

provIf(Lf2, Lf1) :- not not_provIf(Lf2, Lf1), ctx(W1, W2, W3, Lf2, tree2), ctx(W4, W5, W6, Lf1, tree1).

% :- not_provIf(X, leaf111), not_provIf(X, leaf109), not_provIf(X, leaf110), ctx(C1, S1, T1, X, tree2).

%:- not_provIf(Lf2, Lf1), provIf(Lf2, Lf1), ctx(C1, S1, T1, Lf1, tree1), ctx(C2, S2, T2, Lf2, tree2).

not_provIf(Lf2, Lf1) :- in(F, C1), ctx(C1, Sub1, W1, Lf1, tree1), in(F, C2), ctx(C2, Sub2, W2, Lf2, tree2), not geq(Sub2, Sub1), form(F). 

not_provIf(Lf2, Lf1) :- in(F, C1), ctx(C1, Sub1, W1, Lf1, tree1), not in_leaf(F, Lf2), ctx(W2, W3, W4, Lf2, tree2), form(F).

in_leaf(F, Lf) :- in(F, C), ctx(C, W1, W2, Lf, T), form(F).

not_provIf(Lf2, Lf1) :- in(F, C2), ctx(C2, Sub2, lin, Lf2, tree2), in(F, C1), ctx(C1, Sub1, W1, Lf1, tree1), not geq(Sub2, Sub1), form(F). 

not_provIf(Lf2, Lf1) :- in(F, C2), ctx(C2, Sub2, lin, Lf2, tree2), not in_leaf(F, Lf1), ctx(W2, W3, W4, Lf1, tree1), form(F).

stronger(X, X') :- can_use(X, N1), can_use(X', N2), N1 >= N2."

let rec one_provIf fSeq lOpen acc oLeaf = 
  let closed = fSeq oLeaf in
  match lOpen with
    | [] -> 
	let sAcc = String.concat ", " acc in
	  (":- " ^ sAcc ^ ".")
    | h :: b -> 
	let str = "not_provIf(" ^ closed ^ ", " ^ (fSeq h) ^ ")" in 
	  one_provIf fSeq b (str :: acc) oLeaf 

(* let seq_equiv_clauses der1 der2 =  *)
(*   "\nin_geq(F, Sub, Lf2) :- provIf(Lf2, Lf1), in(F, C1), ctx(C1, Sub, W1,  Lf1, "^der1^"), ctx(W2, W3, W4,  Lf2, "^der2^"),  form(F).\n *)

(* :- in(F, C1), ctx(C1, Sub1, W1, Lf, "^der2^"), geq(Sub1, Sub2), not not_in_geq(F, Sub2, Lf), form(F).\n *)

(* 1 {in_geq(F, Sub, Lf), not_in_geq(F, Sub, Lf)} 1 :- form(F), ctx(W1, Sub, W2, Lf, "^der2^").\n *)

(* 1 {in_leq(F, Sub, Lf), not_in_leq(F, Sub, Lf)} 1 :- form(F), ctx(W1, Sub, W2, Lf, "^der1^"). \n *)

(* in_leq(F, Sub1, Lf1) :- in(F, C1), ctx(C1, Sub2, W1,  Lf1, "^der1^"), ctx(W3, Sub1, W1,  Lf1, "^der1^"), not geq(Sub1, Sub2), form(F). *)

(* in_leq(F, Sub, Lf1) :- in(F, C1), ctx(C1, Sub, W1,  Lf1, "^der1^"), form(F). *)
(* " *)

let description = 
  "% We use the following predicate names:
%
%  form(X) ->  Denotes that X is a formula;
%  in(X, Ctx) -> Denotes that the  formula X is in the context Ctx; 
%  union(C1, C2, C3)  -> Denotes that the union of the contexts C1 and C2
%                                   contains the same elements as the context C3;
%  eq(F1, F2) -> Denotes that the formula F1 and F2 are the same.
% not_eq(F1, F2)  -> Denotes that the formulas F1 and F2 are different.
% ctx(Ctx, Sub, Lin/Unb, Leaf, Tree) -> Denotes that the context Ctx belongs to the 
%                                  linear/unbounded subexponential of the open leaf Leaf of the 
%                                  tree Tree.
% in_geq(F, Sub, Leaf) -> Denotes that the formula F is in a context of a subexponential of 
%                                      of the Leaf that is greater than the subexponential Sub.
% provIf(Leaf1, Leaf2) -> Denotes that the Leaf1 is provable if Leaf2 is provable.\n\n"

let write_constraints_to_file file str = 
  let oc = open_out file in 
    fprintf oc "%s\n" str;
    close_out oc

let find_match results = 
  let rec find_match_aux results i =
    match results with
      | [] -> -1
      | true :: b -> i
      | false :: b -> find_match_aux b (i+1)
  in
    find_match_aux results 0

let get_constraints cls1 cls2 = 
(* Auxiliary initial functions *)
  let finitPf tree = "" in
  let fInit tr = tr in
(* Create an initial context for the root sequent. *)
  let fCtxInit1 = create_initial_ctx () in
  let fCtxInit2 = create_initial_ctx () in 
    (* Root sequent. *)
  let seq1 = SEQ([],  LFT (!subexpLeft, fCtxInit1),  
                RGHT (!subexpRight, fCtxInit1)) in
    (* print_term cls1; print_string "\n\n";  print_term cls2; *)
  let seq2 = SEQ([],  LFT (!subexpLeft, fCtxInit2),  
                RGHT (!subexpRight, fCtxInit2)) in
    (* print_term cls1; print_string "\n\n";  print_term cls2; *)
    print_bipole seq1 cls1;  print_string "\n\n"; print_bipole seq2 cls2;
(* Construct constraints binding the root sequents of the two trees. *)
  let bind_constraints = bind_root_constraints fCtxInit1 fCtxInit2 in
  let check_sat_aux lOpen lClosed cnst = 
    let (fSeq, comments1) = create_open_leaf_renaming_function lOpen finitPf [] in 
    let ltermCrude1 = collect_terms_constraints cnst [] in
    let ltermCrude2 = collect_terms_sequents lOpen [] in
    let ltermCrude = remove_repetitions (ltermCrude1 @ ltermCrude2) [] in 
      (* Create a function that assigns a different string to each formula. *)
    let (fterms, comments2) = create_rewrite_function ltermCrude fInit [] in
      (* Rewrite constraints and terms so that they agree with the strings assigned to formulas. *)
    let lterms_rw = List.map fterms ltermCrude in
    let lcnst_rw = apply_rewrite cnst fterms [] in 
      (* Construct the constraints with the membership, empty conditions, and  *)
      (* equality among contexts. *)
    let mem_constraints = build_mem_eq_constraints lcnst_rw [] in
      (* Construct the facts of the form eq(form1, form2) denoting that the formulas *)
      (* form1 and form2 are equal. *)
    let equalities_str = build_simple_equalities lterms_rw lcnst_rw in
    let comments = comments1 @ comments2  in 
    let concat_strings = String.concat "\n\n" (comments @  equalities_str @ mem_constraints)  in
    let final_constraints =  (description^union_clauses_set^concat_strings) in
      write_constraints_to_file "constraints.pl" final_constraints;
      let grep = Unix.open_process_in "lparse constraints.pl | smodels | grep False" in 
	try
	  input_line grep; false
	with End_of_file -> true
  in
  let rec filter_sat ltrees acc  = 
    match ltrees with
      | [] -> acc
      | (lcnst1, lOpen1, lClosed1) :: b -> 
	  let new_sat_constraints = 
	    List.filter (check_sat_aux lOpen1 lClosed1) lcnst1 in 
	    if new_sat_constraints = [] 
	    then filter_sat b acc
	    else filter_sat b ((new_sat_constraints, lOpen1, lClosed1) :: acc)
  in	      
  let check_permut_aux  cnst1 lOpen1 lClosed1 lOpen2 lClosed2 cnst2 =
    let lcnst = cnst1 @ cnst2 in
    let lOpen = lOpen1 @ lOpen2 in 
      (* Create a function that assigns a different string to each open leaf. *)
    let (fSeq, comments1) = create_open_leaf_renaming_function lOpen finitPf [] in 
      (* List.iter print_string comments1;  *)
    let ltermCrude1 = collect_terms_constraints lcnst [] in
    let ltermCrude2 = collect_terms_sequents lOpen [] in
    let ltermCrude = remove_repetitions (ltermCrude1 @ ltermCrude2) [] in 
      (* Create a function that assigns a different string to each formula. *)
    let (fterms, comments2) = create_rewrite_function ltermCrude fInit [] in
      (* Rewrite constraints and terms so that they agree with the strings assigned to formulas. *)
    let lterms_rw = List.map fterms ltermCrude in
    let lcnst_rw = apply_rewrite lcnst fterms [] in 
      (* Constructs the contraints involving the ordering of subexponentials. *)
    let geq_constraints = build_sexp_constraints () in 
      (* Construct the constraints with the membership, empty conditions, and  *)
      (* equality among contexts. *)
    let mem_constraints = build_mem_eq_constraints lcnst_rw [] in
      (* Construct the facts of the form eq(form1, form2) denoting that the formulas *)
      (* form1 and form2 are equal. *)
    let equalities_str = build_simple_equalities lterms_rw lcnst_rw in
      (* Constructs constraints of the form ctx(num, Sub, Seq) denoting that the context *)
      (* num belongs to the subexponential context Sub of sequent Seq. *)
    let ctx_constraints1  = List.flatten (List.map (build_ctx_numbering fSeq fterms "tree1") lOpen1) in
    let ctx_constraints2 = List.flatten (List.map (build_ctx_numbering fSeq fterms "tree2") lOpen2) in
      (* Construct the clauses specifying that each leaf of derivation 2 has to be  *)
      (* in at least one provIf relation.  *)
    let provIf_clauses = List.map (one_provIf fSeq lOpen1 []) lOpen2 in
    let comments = comments1 @ comments2  in 
    let ctx_contraints = ctx_constraints1 @ ctx_constraints2 in
    let concat_strings = String.concat "\n\n" (comments @ bind_constraints  @ equalities_str @ provIf_clauses @ mem_constraints 
					       @ ctx_contraints @ geq_constraints)  in
    let constraints_with_clauses = 
      (union_clauses_set)^(subsume_clauses "tree1" "tree2")^(seq_equiv_clauses "tree1" "tree2") in
    let final_constraints =  (description^constraints_with_clauses^concat_strings) in
      write_constraints_to_file "constraints.pl" final_constraints;
      try
	let grep = Unix.open_process_in "lparse constraints.pl | smodels | grep False" in 
	  input_line grep; false
      with End_of_file -> true
	| _ -> 
	    print_string "Caught an exception, when checking whether the trees permute:"; 
	    print_string "\n ---------------- TREE 1 --------------\n\n";
	    print_list_sequents (lOpen1 @ lClosed1);
	    print_string "\n\nWhere:";
	    (* print_list_constraints lcnst1; *)
	    print_constraints cnst1;
	    print_string "\n ---------------- TREE 2 --------------\n\n";
	    print_list_sequents (lOpen2 @ lClosed2);
	    print_string "\n\nWhere:";
	    print_constraints cnst2 ; true
  in
  let rec check_sat_trees lOpen1 lClosed1 ltrees2 cnst1 = 
    match ltrees2 with
      | [] -> 
	  print_string "\n\n DID NOT FIND A MATCH\n"; 
	  print_string "\n ---------------- TREE 1 --------------\n\n";
	  print_list_sequents (lOpen1 @ lClosed1);
	  print_string "\n\nWhere:";
	  print_constraints cnst1;
	  (false, cnst1, lOpen1, lClosed1)
      | (lcnst2, lOpen2, lClosed2) :: b -> 
	  let results = List.map (check_permut_aux cnst1 lOpen1 lClosed1 lOpen2 lClosed2) lcnst2 in
	  let i = find_match results in
	    if i = -1 then (check_sat_trees lOpen1 lClosed1 b cnst1)	      
	    else
	      begin
		print_string "\n\n FOUND A MATCH\n" ;
		print_string "\n ---------------- TREE 1 --------------\n\n";
		print_list_sequents (lOpen1 @ lClosed1);
		print_string "\n\nWhere:";
		print_constraints cnst1;
		print_string "\n ---------------- TREE 2 --------------\n\n";
		print_list_sequents (lOpen2 @ lClosed2);
		print_string "\n\nWhere:";
		print_constraints (List.nth lcnst2 i);
		(true, List.nth lcnst2 i, lOpen2, lClosed2)
	      end
  in
  let rec check_permut ltrees1 ltrees2 acc = 
    match ltrees1 with
      | [] -> acc
      | (lncst1, lOpen1, lClosed1) :: b -> 
	  let results = List.map (check_sat_trees lOpen1 lClosed1 ltrees2) lncst1 in
	    check_permut b ltrees2 (results :: acc)
  in
  let trees1 =  (build_2_bipole_tree1 cls1 cls2 seq1) in
  let sat_trees1 = filter_sat trees1 [] in
  (* let (lncst1, lOpen1, lClosed1) = List.hd sat_trees1 in *)
  let ltrees2 = build_2_bipole_tree2 cls2 cls1 seq2 in
    check_permut sat_trees1 ltrees2 []
  (* let (tf, cnst2, lOpen2, lClosed2) = check_sat_trees lOpen1 lClosed1 ltrees2 cnst1 in  *)
    (* let _ = check_permut cnst1 lOpen1 lClosed1 lOpen2 lClosed2 cnst2 in *)
    (* tf *)
