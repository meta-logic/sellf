su gente nao esta com a mesma versao nao...bexp un unb.
subexp slin lin.
subexp sunb unb.

subexprel slin <= un.
subexprel sunb <= un.
subexprel slin <= sunb.

context un.

%solve :- lft (F), rght(F).
%solve :- rght (bot), solve.
%solve :- rght (lone), one.
%solve :- rght (ltop), top.

solve :- rght (tensor F1 F2), (rght F1 [slin]-o solve),  (rght F2 [slin]-o solve).
solve :- rght (with F1 F2), (rght F1 [slin]-o solve) & (rght F2 [slin]-o solve).
%solve :- rght (par F1 F2), (rght F1 [slin]-o (rght F2 [slin]-o solve)).
%solve :- rght (plus F1 F2), (rght F1 [slin]-o solve).
%solve :- rght (plus F1 F2), (rght F2 [slin]-o solve).
%solve :- rght (bng (F1)), [sunb]bang (rght F1 [slin]-o solve).
%solve :- rght (quest (F1)), (rght F1 [sunb]-o solve).

%solve :- lft (lone), solve.
%solve :- lft (zero), top.
%solve :- lft (with F1 F2), (lft F1 [slin]-o solve).
%solve :- lft (with F1 F2), (lft F2 [slin]-o solve).
%solve :- lft (tensor F1 F2), (lft F1 [slin]-o (lft F2 [slin]-o solve)).
%solve :- lft (par F1 F2), (lft F1 [slin]-o solve),  (lft F2 [slin]-o solve).
%solve :- lft (plus F1 F2), (lft F1 [slin]-o solve) & (lft F2 [slin]-o solve).
%solve :- lft (bng (F1)), (lft F1 [sunb]-o solve).
%solve :- lft (quest (F1)), [sunb]bang (lft F1 [slin]-o solve).

